///////////////////////////////////////////////////////////////////////////////////////
// PROTOCOL START
///////////////////////////////////////////////////////////////////////////////////////

static constexpr uint16_t s_raceInfoVersion = 1;
static constexpr uint16_t s_participantRaceStateVersion = 1;
static constexpr uint16_t s_participantTelemetryVersion = 2;

//
// dynamic size string, sent as the length as a byte and a char array of 'm_len' elements
struct DynamicSizeString {
    unsigned char m_len{};                  // 1 byte
    UDPCharBuf m_str{};                     // m_len bytes
};

//
// List of floats
struct UDPFloatList {
    unsigned char m_len{};                                  // 1 byte
    UDPList<float> m_data;                                  // m_len x 4 bytes
};


//
// packet type
enum class UDPPacketType : unsigned char {
    RaceInfo = 0,
    ParticipantRaceState = 1,
    ParticipantVehicleTelemetry = 2,
    SessionStopped = 3
};


//
// flag types
enum class UDPFlagType : unsigned char {
    ChequeredFlag = 0,
    YellowFlag = 1,
    WhiteFlag = 2,
    BlueFlag = 3
};

///////////////////////////////////////////////////////////////////////////////////////
// RACE INFO PACKET
///////////////////////////////////////////////////////////////////////////////////////

//
// Session State
enum class UDPRaceSessionState : unsigned char {
    Inactive = 0,
    Active = 1,
    Complete = 2
};


struct UDPRaceInfo {
    unsigned char m_packetType = (unsigned char)UDPPacketType::RaceInfo; // 1 byte
    uint16_t m_packetVersion = s_raceInfoVersion; // 2 bytes

    DynamicSizeString m_track{};            // see DynamicSizeString (above)
    DynamicSizeString m_layout{};           // see DynamicSizeString (above)
    DynamicSizeString m_season{};           // see DynamicSizeString (above)
    DynamicSizeString m_weather{};          // see DynamicSizeString (above)
    DynamicSizeString m_session{};          // see DynamicSizeString (above) 
    DynamicSizeString m_gameMode{};         // see DynamicSizeString (above)
    float m_layoutLength{};                 // 4 bytes
    float m_duration{};                     // 4 bytes
    float m_overtime{};                     // 4 bytes
    float m_ambientTemperature{};           // 4 bytes
    float m_trackTemperature{};             // 4 bytes
    unsigned char m_isLaps{};               // 1 byte
    UDPRaceSessionState m_state{};          // 1 byte
    unsigned char m_numParticipants{};      // 1 byte
};


///////////////////////////////////////////////////////////////////////////////////////
// PARTICIPANT RACE STATE
///////////////////////////////////////////////////////////////////////////////////////
struct UDPParticipantRaceState {
    unsigned char m_packetType = (unsigned char)UDPPacketType::ParticipantRaceState; // 1 byte
    uint16_t m_packetVersion = s_participantRaceStateVersion; // 2 bytes

    unsigned char m_isPlayer{};             // 1 byte
    int32_t m_vehicleId{};                  // 4 bytes

    DynamicSizeString m_vehicleName;        // see DynamicSizeString (above)
    DynamicSizeString m_driverName;         // see DynamicSizeString (above)
    DynamicSizeString m_liveryId{};         // see DynamicSizeString (above)
    DynamicSizeString m_vehicleClass{};     // see DynamicSizeString (above)

    int32_t m_racePos{};                                    // 4 bytes
    int32_t m_currentLap{};                                 // 4 bytes

    float m_currentLapTime{};                               // 4 bytes
    float m_bestLapTime{};                                  // 4 bytes
    float m_lapProgress{};                                  // 4 bytes

    int32_t m_currentSector{};                              // 4 bytes

    UDPFloatList m_currentSectorTimes{};                    // see UDPFloatList (above)
    UDPFloatList m_bestSectorTimes{};                       // see UDPFloatList (above)

    unsigned char m_inPits{};                               // 1 byte
    unsigned char m_sessionFinished{};                      // 1 byte
    unsigned char m_dq{};                                   // 1 byte

    uint32_t m_flags{};                                     // 4 bytes

    class HadronVehicleComponent* m_pVehComp{};             // 0 bytes (not written)
};


///////////////////////////////////////////////////////////////////////////////////////
// PARTICIPANT VEHICLE TELEMETRY
///////////////////////////////////////////////////////////////////////////////////////

//
// structure for a 3d vector
struct UDPVec3 {
    float m_vec[3] = { 0.0f, 0.0f, 0.0f };                  // 12 bytes
};

//
// structure for a quaternion
struct UDPQuat {
    float m_quat[4] = { 0.0f, 0.0f, 0.0f, 0.0f };           // 16 bytes
};

//
// structure for a single telemetry wheel data
struct UDPVehicleTelemetryWheel {
    // contact data
    int m_contactMaterialHash = 0;                          // 4 bytes

    // wheel data
    float m_angVel = 0.0f;                                  // 4 bytes
    float m_linearSpeed = 0.0f;                             // 4 bytes

    // tyre data
    UDPVec3 m_slideLS;                                      // 12 bytes
    UDPVec3 m_forceLS;                                      // 12 bytes
    UDPVec3 m_momentLS;                                     // 12 bytes
    float m_contactRadius = 0.0f;                           // 4 bytes
    float m_pressure = 0.0f;                                // 4 bytes
    float m_inclination = 0.0f;                             // 4 bytes
    float m_slipRatio = 0.0f;                               // 4 bytes
    float m_slipAngle = 0.0f;                               // 4 bytes

    // thermodynamics data
    UDPVec3 m_tread;                                        // 12 bytes
    float m_carcass = 0.0f;                                 // 4 bytes
    float m_internalAir = 0.0f;                             // 4 bytes
    float m_wellAir = 0.0f;                                 // 4 bytes
    float m_rim = 0.0f;                                     // 4 bytes
    float m_brake = 0.0f;                                   // 4 bytes

    // suspension data
    float m_springStrain = 0.0f;                            // 4 bytes
    float m_damperVelocity = 0.0f;                          // 4 bytes

    // drivetrain data
    float m_hubTorque = 0.0f;                               // 4 bytes
    float m_hubPower = 0.0f;                                // 4 bytes
    float m_wheelTorque = 0.0f;                             // 4 bytes
    float m_wheelPower = 0.0f;                              // 4 bytes
};

//
// structure for the telemetry chassis data
struct UDPVehicleTelemetryChassis {
    UDPVec3 m_posWS;                                        // 12 bytes
    UDPQuat m_quat;                                         // 16 bytes
    UDPVec3 m_angularVelocityWS;                            // 12 bytes
    UDPVec3 m_angularVelocityLS;                            // 12 bytes
    UDPVec3 m_velocityWS;                                   // 12 bytes
    UDPVec3 m_velocityLS;                                   // 12 bytes
    UDPVec3 m_accelerationWS;                               // 12 bytes
    UDPVec3 m_accelerationLS;                               // 12 bytes
    float m_overallSpeed = 0.0f;                            // 4 bytes
    float m_forwardSpeed = 0.0f;                            // 4 bytes
    float m_sideslip = 0.0f;                                // 4 bytes
};

//
// Per gear telemetry
struct UDPVehicleTelemetryGear {
    float m_upshiftRPM{};                                   // 4 bytes
    float m_downshiftRPM{};                                 // 4 bytes
};

//
// List of telemetry gear structures
struct UDPVehicleTelemetryGearList {
    unsigned char m_len{};                                  // 1 byte
    UDPList<UDPVehicleTelemetryGear> m_data{};              // see UDPVehicleTelemetryGear (above)
    // m_len x UDPVehicleTelemetryGear bytes
};

//
// structure for the telemetry drivetrain data
struct UDPVehicleTelemetryDrivetrain {
    // ICE data
    float m_engineRPM = 0.0f;                               // 4 bytes
    float m_engineRevRatio = 0.0f;                          // 4 bytes
    float m_engineTorque = 0.0f;                            // 4 bytes
    float m_enginePower = 0.0f;                             // 4 bytes
    float m_engineLoad = 0.0f;                              // 4 bytes
    float m_engineTurboRPM = 0.0f;                          // 4 bytes
    float m_engineTurboBoostPressure = 0.0f;                // 4 bytes
    float m_fuelRemaining = 0.0f;                           // 4 bytes
    float m_fuelUseRate = 0.0f;                             // 4 bytes
    float m_engineOilPressure = 0.0f;                       // 4 bytes
    float m_engineOilTemperature = 0.0f;                    // 4 bytes
    float m_engineCoolantTemperature = 0.0f;                // 4 bytes
    float m_exhaustGasTemperature = 0.0f;                   // 4 bytes

    // MGU data
    float m_motorRPM = 0.0f;                                // 4 bytes
    float m_batteryRemaining = 0.0f;                        // 4 bytes
    float m_batteryUseRate = 0.0f;                          // 4 bytes

    // drivetrain data
    float m_transmissionRPM = 0.0f;                         // 4 bytes
    float m_gearboxInputRPM = 0.0f;                         // 4 bytes
    float m_gearboxOutputRPM = 0.0f;                        // 4 bytes
    float m_gearboxTorque = 0.0f;                           // 4 bytes
    float m_gearboxPower = 0.0f;                            // 4 bytes
    float m_gearboxLoadIn = 0.0f;                           // 4 bytes
    float m_gearboxLoadOut = 0.0f;                          // 4 bytes
    float m_timeSinceShift = 0.0f;                          // 4 bytes
    float m_estDrivenSpeed = 0.0f;                          // 4 bytes
    float m_outputTorque = 0.0f;                            // 4 bytes
    float m_outputPower = 0.0f;                             // 4 bytes
    float m_outputEfficiency = 0.0f;                        // 4 bytes

    // small data
    unsigned char m_starterActive = 0;                      // 1 byte
    unsigned char m_engineRunning = 0;                      // 1 byte
    unsigned char m_engineFanRunning = 0;                   // 1 byte
    unsigned char m_revLimiterActive = 0;                   // 1 byte
    unsigned char m_tractionControlActive = 0;              // 1 byte
    unsigned char m_speedLimiterEnabled = 0;                // 1 byte
    unsigned char m_speedLimiterActive = 0;                 // 1 byte

    UDPVehicleTelemetryGearList m_gear;
};


//
// structure for the telemetry suspension data
struct UDPVehicleTelemetrySuspension {
    UDPFloatList m_avgLoads;                                // see UDPFloatList (above)
    float m_loadBias = 0.0f;                                // 4 bytes
};

//
// structure for the telemetry input data
struct UDPVehicleTelemetryInput {
    float m_steering = 0.0f;                                // 4 bytes
    float m_accelerator = 0.0f;                             // 4 bytes
    float m_brake = 0.0f;                                   // 4 bytes
    float m_clutch = 0.0f;                                  // 4 bytes
    float m_handbrake = 0.0f;                               // 4 bytes
    int32_t m_gear = 0;                                     // 4 bytes
};

//
// structure for the telemetry setup data
struct UDPVehicleTelemetrySetup {
    float m_brakeBias = 0.f;                                // 4 bytes
    float m_frontAntiRollStiffness = 0.f;                   // 4 bytes
    float m_rearAntiRollStiffness = 0.f;                    // 4 bytes
    float m_regenLimit = 0.f;                               // 4 bytes
    float m_deployLimit = 0.f;                              // 4 bytes
    unsigned char m_absLevel = 0;                           // 1 byte
    unsigned char m_tcsLevel = 0;                           // 1 byte
};

//
// structure for the general telemetry vehicle data
struct UDPVehicleTelemetryGeneral {
    UDPVec3 m_centerOfGravity;                              // 12 bytes
    float m_steeringWheelAngle = 0.0f;                      // 4 bytes
    float m_totalMass = 0.0f;                               // 4 bytes
    float m_drivenWheelAngVel = 0.0f;                       // 4 bytes
    float m_nonDrivenWheelAngVel = 0.0f;                    // 4 bytes
    float m_estRollingSpeed = 0.0f;                         // 4 bytes
    float m_estLinearSpeed = 0.0f;                          // 4 bytes
    float m_totalBrakeForce = 0.0f;                         // 4 bytes
    unsigned char m_absActive = false;                      // 1 byte
};

//
// structure for the constant vehicle data
struct UDPVehicleTelemetryConstant {
    UDPVec3 m_chassisBBMin;                                 // 12 bytes
    UDPVec3 m_chassisBBMax;                                 // 12 bytes
    float m_starterIdleRPM;                                 // 4 bytes
    float m_engineTorquePeakRPM;                            // 4 bytes
    float m_enginePowerPeakRPM;                             // 4 bytes
    float m_engineMaxRPM;                                   // 4 bytes
    float m_engineMaxTorque;                                // 4 bytes
    float m_engineMaxPower;                                 // 4 bytes
    float m_engineMaxBoost;                                 // 4 bytes
    float m_fuelCapacity;                                   // 4 bytes
    float m_batteryCapacity;                                // 4 bytes
    float m_trackWidthFront;                                // 4 bytes
    float m_trackWidthRear;                                 // 4 bytes
    float m_wheelbase;                                      // 4 bytes
    unsigned char m_numberOfWheels;                         // 1 byte
    unsigned char m_numberOfForwardGears;                   // 1 byte
    unsigned char m_numberOfReverseGears;                   // 1 byte
    unsigned char m_isHybrid;                               // 1 byte
};

//
// List of telemetry wheel structures
struct UDPVehicleTelemetryWheelList {
    unsigned char m_len{};                                  // 1 byte
    UDPList<UDPVehicleTelemetryWheel> m_data{};             // see UDPVehicleTelemetryWheel (above)
    // m_len x UDPVehicleTelemetryWheel bytes
};

//
// structure for the telemetry of a single vehicle
struct UDPVehicleTelemetry {
    unsigned char m_packetType = (unsigned char)UDPPacketType::ParticipantVehicleTelemetry;     // 1 byte
    uint16_t m_packetVersion = s_participantTelemetryVersion;                                   // 2 bytes

    int32_t m_vehicleId = -1;                                                                   // 4 bytes
    UDPVehicleTelemetryWheelList m_wheels;                  // see UDPVehicleTelemetryWheelList (above)
    UDPVehicleTelemetryChassis m_chassis;                   // see UDPVehicleTelemetryChassis (above)
    UDPVehicleTelemetryDrivetrain m_drivetrain;             // see UDPVehicleTelemetryDriveTrain (above)
    UDPVehicleTelemetrySuspension m_suspension;             // see UDPVehicleTelemetrySuspension (above)
    UDPVehicleTelemetryInput m_input;                       // see UDPVehicleTelemetryInput (above)
    UDPVehicleTelemetrySetup m_setup;                       // see UDPVehicleTelemetrySetup (above)
    UDPVehicleTelemetryGeneral m_general;                   // see UDPVehicleTelemetryGeneral (above)
    UDPVehicleTelemetryConstant m_constant;                 // see UDPVehicleTelemetryConstant (above)
};


///////////////////////////////////////////////////////////////////////////////////////
// PROTOCOL END
///////////////////////////////////////////////////////////////////////////////////////