﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace simpleudpserver
{
    public partial class Form1 : Form
    {
        DataStore m_dataStore = null;

        static int s_maxStatusUpdates = 12;
        static int s_maxNumLeaderboardEntries = 32;
        static int s_noDataWaitBeforeReset = 30;

        string m_statusUpdateString = string.Empty;
        List<string> m_statusUpdates = new List<string>();

        List<UDPParticipantRaceState> m_leaderboard = null;
        UDPVehicleTelemetry m_selectedTelemetry = null;
        int m_selectedVehicleId = -1;


        public Form1(DataStore ds)
        {
            m_dataStore = ds;
            InitializeComponent();

            for (int i = 0; i < s_maxNumLeaderboardEntries; ++i)
            {
                this.leaderBoardBox.Items.Add(new UDPParticipantRaceState());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Timer timer = new Timer();
            timer.Interval = 33; // refresh at 30 hz
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (raceinfo.Text != m_dataStore.m_raceInfoString)
            {
                raceinfo.Text = m_dataStore.m_raceInfoString;
                raceinfo.Refresh();
            }

            statusUpdate();
            leaderboardUpdate();
            telemetryDisplayUpdate();

            if (m_dataStore.timeSinceLastWrite() > s_noDataWaitBeforeReset)
            {
                m_dataStore.clear();
            }
        }

        public void statusUpdate()
        {
            m_statusUpdates = new List<string>(m_dataStore.m_statusUpdates);
            if (m_statusUpdates.Count > s_maxStatusUpdates)
            {
                int numToRemove = m_statusUpdates.Count - s_maxStatusUpdates;
                m_statusUpdates.RemoveRange(0, numToRemove);
            }

            m_statusUpdateString = "\r\n";
            foreach (string s in m_statusUpdates)
            {
                m_statusUpdateString += s;
            }

            if (m_statusUpdateString != statusupdates.Text)
            {
                statusupdates.Text = m_statusUpdateString;
                statusupdates.Refresh();
            }
        }

        private void leaderboardUpdate()
        {
            int pendingSelectedIdx = -1;

            List<UDPParticipantRaceState> prevLeaderboard = null;
            if (m_leaderboard != null)
            {
                m_dataStore.copyRaceStates(m_leaderboard, out prevLeaderboard);
            }

            m_leaderboard = m_dataStore.getLeaderboard();
            for (int i = 0; i < s_maxNumLeaderboardEntries; ++i)
            {
                if (i < m_leaderboard.Count)
                {
                    if (m_leaderboard[i].m_vehicleId == m_selectedVehicleId)
                    {
                        pendingSelectedIdx = i;
                    }

                    leaderBoardBox.Items[i] = m_leaderboard[i];
                }
                else
                {
                    leaderBoardBox.Items[i] = new UDPParticipantRaceState();
                }
            }

            if (leaderboardChanged(prevLeaderboard))
            {
                leaderBoardBox.SelectedIndex = pendingSelectedIdx;
                leaderBoardBox.Refresh();
            }
        }

        public void telemetryDisplayUpdate()
        {
            if (m_selectedVehicleId != -1)
            {
                m_selectedTelemetry = m_dataStore.getTelemetryForVehicle(m_selectedVehicleId);
                if (m_selectedTelemetry != null)
                {
                    if(telemetryDisplay.Text != m_selectedTelemetry.ToString())
                    {
                        telemetryDisplay.Text = m_selectedTelemetry.ToString();
                        telemetryDisplay.Refresh();
                    }
                }
                else
                {
                    telemetryDisplay.Text = string.Empty;
                }
            }
        }


        private bool leaderboardChanged(List<UDPParticipantRaceState> prevLeaderboard)
        {
            if(m_leaderboard == null || prevLeaderboard == null)
            {
                return false;
            }    

            if(prevLeaderboard.Count != m_leaderboard.Count)
            {
                return true;
            }

            for (int i = 0; i < m_leaderboard.Count; ++i)
            {
                if (m_leaderboard[i].m_vehicleId != prevLeaderboard[i].m_vehicleId)
                {
                    return true;
                }
            }

            return false;
        }


        private void leaderboardBox_OnClick(object sender, EventArgs e)
        {
            if (leaderBoardBox.SelectedIndex >= m_leaderboard.Count)
            {
                leaderBoardBox.SelectedIndex = m_leaderboard.Count - 1;
            }

            if (leaderBoardBox.SelectedIndex < 0)
            {
                return;
            }

            UDPParticipantRaceState rs = (UDPParticipantRaceState)leaderBoardBox.Items[leaderBoardBox.SelectedIndex];
            if (rs != null)
            {
                m_selectedVehicleId = rs.m_vehicleId;
            }
        }
    }
}
