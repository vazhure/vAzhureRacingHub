﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace simpleudpserver
{
    internal static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DataStore ds = new DataStore();

            UDPThread t = new UDPThread(ds, args);
            t.startThread();

            Application.ApplicationExit += t.shutdown;
            Application.Run(new Form1(ds));
        }
    }
}
