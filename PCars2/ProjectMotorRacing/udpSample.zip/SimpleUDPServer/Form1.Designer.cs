﻿namespace simpleudpserver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.leaderboardBackground = new System.Windows.Forms.TextBox();
            this.raceinfo = new System.Windows.Forms.TextBox();
            this.statusupdates = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.leaderBoardBox = new System.Windows.Forms.ListBox();
            this.telemetryDisplay = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Load += Form1_Load;
            this.SuspendLayout();
            // 
            // leaderboardBackground
            // 
            this.leaderboardBackground.BackColor = System.Drawing.Color.Gray;
            this.leaderboardBackground.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leaderboardBackground.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.leaderboardBackground.Location = new System.Drawing.Point(14, 16);
            this.leaderboardBackground.Multiline = true;
            this.leaderboardBackground.Name = "leaderboardBackground";
            this.leaderboardBackground.ReadOnly = true;
            this.leaderboardBackground.Size = new System.Drawing.Size(266, 661);
            this.leaderboardBackground.TabIndex = 0;
            // 
            // raceinfo
            // 
            this.raceinfo.AcceptsReturn = true;
            this.raceinfo.AllowDrop = true;
            this.raceinfo.BackColor = System.Drawing.Color.Gray;
            this.raceinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raceinfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.raceinfo.Location = new System.Drawing.Point(666, 16);
            this.raceinfo.Margin = new System.Windows.Forms.Padding(3, 2, 2, 2);
            this.raceinfo.Multiline = true;
            this.raceinfo.Name = "raceinfo";
            this.raceinfo.ReadOnly = true;
            this.raceinfo.Size = new System.Drawing.Size(351, 420);
            this.raceinfo.TabIndex = 1;
            // 
            // statusupdates
            // 
            this.statusupdates.BackColor = System.Drawing.Color.Gray;
            this.statusupdates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusupdates.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.statusupdates.Location = new System.Drawing.Point(666, 466);
            this.statusupdates.Margin = new System.Windows.Forms.Padding(3, 2, 2, 2);
            this.statusupdates.MaxLength = 2048;
            this.statusupdates.Multiline = true;
            this.statusupdates.Name = "statusupdates";
            this.statusupdates.ReadOnly = true;
            this.statusupdates.Size = new System.Drawing.Size(351, 211);
            this.statusupdates.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.Location = new System.Drawing.Point(21, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "LEADERBOARD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label2.Location = new System.Drawing.Point(674, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "SESSION INFO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label3.Location = new System.Drawing.Point(663, 451);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "STATUS UPDATES";
            // 
            // leaderBoardBox
            // 
            this.leaderBoardBox.BackColor = System.Drawing.Color.Gray;
            this.leaderBoardBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.leaderBoardBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leaderBoardBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.leaderBoardBox.FormattingEnabled = true;
            this.leaderBoardBox.ItemHeight = 15;
            this.leaderBoardBox.Location = new System.Drawing.Point(15, 32);
            this.leaderBoardBox.Margin = new System.Windows.Forms.Padding(2, 11, 2, 2);
            this.leaderBoardBox.Name = "leaderBoardBox";
            this.leaderBoardBox.Size = new System.Drawing.Size(257, 630);
            this.leaderBoardBox.TabIndex = 6;
            this.leaderBoardBox.Click += new System.EventHandler(this.leaderboardBox_OnClick);
            // 
            // telemetryDisplay
            // 
            this.telemetryDisplay.AcceptsReturn = true;
            this.telemetryDisplay.AllowDrop = true;
            this.telemetryDisplay.BackColor = System.Drawing.Color.Gray;
            this.telemetryDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telemetryDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.telemetryDisplay.Location = new System.Drawing.Point(285, 16);
            this.telemetryDisplay.Margin = new System.Windows.Forms.Padding(3, 2, 2, 2);
            this.telemetryDisplay.Multiline = true;
            this.telemetryDisplay.Name = "telemetryDisplay";
            this.telemetryDisplay.ReadOnly = true;
            this.telemetryDisplay.Size = new System.Drawing.Size(378, 661);
            this.telemetryDisplay.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Location = new System.Drawing.Point(327, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "TELEMETRY DISPLAY";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1034, 692);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.telemetryDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.leaderBoardBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.statusupdates);
            this.Controls.Add(this.raceinfo);
            this.Controls.Add(this.leaderboardBackground);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "PMR: Companion App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox leaderboardBackground;
        private System.Windows.Forms.TextBox raceinfo;
        private System.Windows.Forms.TextBox statusupdates;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox leaderBoardBox;
        private System.Windows.Forms.TextBox telemetryDisplay;
        private System.Windows.Forms.Label label4;
    }
}

