Run simpleudpserver.exe in bin/


By default, the application listens to port 7576 on multicast group 224.0.0.150
You can modify this by setting the following commandline arguments

multicast=true/false
multicast_group=ip_address
port=port_number

eg
multicast=false port=7581
multicast_group=226.0.0.150 port=7581



The application shows you 4 frames
1. leaderboard of the race (empty until in race)
2. telemetry display of the vehicle selected in the leaderboard
3. session info
4. status updates (sector and lap crossings and session finishes)



The game sends three types of packets (full details can be found in docs/)
- UDPRaceInfo
	Contains information about the race as a whole (track, weather, number of participants etc)
- UDPParticipantRaceState
	Contains information about one race participant (id, name, vehicle, livery, sector and lap times etc)
- UDPVehicleTelemetry
	Contains information about the vehicle telemetry for one race participant (id, engine data, chassis data etc)